import 'package:file_saver/src/platform_handler/platform_handler.dart';

PlatformHandler getPlatformHandler() {
  throw UnsupportedError('Cannot create PlatformHandler');
}
