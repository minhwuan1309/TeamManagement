package com.example.team_manage_frontend

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
